/**
 * @license
 * Copyright (c) 2014, 2019, Oracle and/or its affiliates.
 * The Universal Permissive License (UPL), Version 1.0
 * @ignore
 */
define(["appController","utils","ojs/ojcore","knockout","jquery","accUtils","ojs/ojmodule-element-utils","ojs/ojnavigationlist"],(function(e,n,o,t,a,i,s){return function(){var o=this;n.getSetLanguage(),"Y"==e.userDetails.admin&&(o.sysModuleConfig=t.observable(s.createConfig(n.appConstants.sysModuleConfig)),o.selectedItem=t.observable("systemAdminOrganizations"),o.connected=function(){i.announce("Admin page loaded."),document.title="Admin"},o.tabChanged=function(e){var n=e.detail.value,t="views/"+n+".html",a="viewModels/"+n;o.sysModuleConfig(s.createConfig({viewPath:t,viewModelPath:a,params:{parentRouter:o.router}}))})}}));