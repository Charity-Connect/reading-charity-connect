/**
 * @license
 * Copyright (c) 2014, 2019, Oracle and/or its affiliates.
 * The Universal Permissive License (UPL), Version 1.0
 * @ignore
 */
define(["utils","ojs/ojcore","knockout","jquery","accUtils","ojs/ojmodule-element-utils","ojs/ojnavigationlist"],(function(e,o,n,t,i,a){return function(){var o=this;o.sysModuleConfig=n.observable(a.createConfig(e.appConstants.sysModuleConfig)),o.selectedItem=n.observable("systemAdminOrganizations"),o.connected=function(){i.announce("Admin page loaded."),document.title="Admin"},o.tabChanged=function(e){var n=e.detail.value,t="views/"+n+".html",i="viewModels/"+n;o.sysModuleConfig(a.createConfig({viewPath:t,viewModelPath:i,params:{parentRouter:o.router}}))}}}));