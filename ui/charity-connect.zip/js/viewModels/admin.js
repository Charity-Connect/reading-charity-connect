/**
 * @license
 * Copyright (c) 2014, 2019, Oracle and/or its affiliates.
 * The Universal Permissive License (UPL), Version 1.0
 * @ignore
 */
define(["appController","utils","ojs/ojcore","knockout","jquery","accUtils","ojs/ojmodule-element-utils","ojs/ojnavigationlist"],(function(e,o,n,t,i,a,s){return function(){var n=this;"Y"==e.userDetails.admin&&(n.sysModuleConfig=t.observable(s.createConfig(o.appConstants.sysModuleConfig)),n.selectedItem=t.observable("systemAdminOrganizations"),n.connected=function(){a.announce("Admin page loaded."),document.title="Admin"},n.tabChanged=function(e){var o=e.detail.value,t="views/"+o+".html",i="viewModels/"+o;n.sysModuleConfig(s.createConfig({viewPath:t,viewModelPath:i,params:{parentRouter:n.router}}))})}}));